import React from 'react';
import  './header.css';

const Header = () => (
    <header id="main-header">Sistema</header>
);

export default Header;